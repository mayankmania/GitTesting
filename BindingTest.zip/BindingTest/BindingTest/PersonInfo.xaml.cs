﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace BindingTest
{
    public partial class PersonInfo : UserControl
    {
        public PersonVM PersonVM { get; set; }
        public PersonInfo()
        {
            PersonVM = new BindingTest.PersonVM();
            InitializeComponent();
            (this.Content as FrameworkElement).DataContext = this.PersonVM;
        }

        void PersonVM_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            PersonSource = this.PersonVM.Person;
        }

        public Person PersonSource
        {
            get { return GetValue(PersonProperty) as Person; }
            set { SetValue(PersonProperty, value); }
        }

        public static DependencyProperty PersonProperty = DependencyProperty.Register("PersonSource", typeof(Person), typeof(PersonInfo), new PropertyMetadata(OnPersonUpdate));

        private static void OnPersonUpdate(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (e.OldValue != e.NewValue)
            {
                if (((PersonInfo)d).PersonVM == null)
                    ((PersonInfo)d).PersonVM = new PersonVM();
                var viewModel = ((PersonInfo)d).PersonVM;
                viewModel.Person = ((Person)e.NewValue);
            }
        }
    }
}
