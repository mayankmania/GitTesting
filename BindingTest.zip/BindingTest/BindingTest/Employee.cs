﻿using System;
using System.ComponentModel;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace BindingTest
{
    public class Employee : Person
    {
        public Address Address { get; set; }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Address
    {
        public string City { get; set; }
    }

    public class EmployeeVM : BaseVM
    {
        public EmployeeVM()
        {
            Person = new Person { Id = 2, Name = "Amit" };
        }

        public Person _personData;
        public Person Person
        {
            get
            {
                return _personData;
            }
            set
            {
                _personData = value;
                OnPropertyChanged("Person");
            }
        }

        public int Id
        {
            get
            {
                return Person.Id;
            }
            set
            {
                Person.Id = value;
                OnPropertyChanged("Person");
            }
        }

        internal void Update(Person person)
        {
            this.Person = person;
        }

        internal void RefreshUI()
        {
            OnPropertyChanged("Person"); 
        }
    }

    public class BaseVM : INotifyPropertyChanged
    {
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class PersonVM : BaseVM
    {
        public PersonVM()
        {
            Person = new Person();
        }

        public int Id
        {
            get { return Person.Id; }
            set
            {
                Person.Id = value;
                OnPropertyChanged("Id");
            }
        }

        public string Name
        {
            get { return Person.Name; }
            set { Person.Name = value; OnPropertyChanged("Name"); }
        }

        private Person _person;
        public Person Person
        {
            get
            {
                return _person;
            }
            set
            {
                _person = value;
                OnPropertyChanged("Person");
                OnPropertyChanged("Id");
                OnPropertyChanged("Name");
            }
        }

        internal void Update(Person value)
        {
            Id = value.Id;
            Name = value.Name;
        }
    }
}
